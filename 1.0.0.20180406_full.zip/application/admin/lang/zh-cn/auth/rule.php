<?php

return [
    'Toggle all'                                                => '显示全部',
    'Condition'                                                 => '规则条件',
    'Remark'                                                    => '备注',
    'Icon'                                                      => '图标',
    'Alert'                                                     => '警告',
    'Name'                                                      => '规则',
    'Controller/Action'                                         => '控制器名/方法名',
    'Ismenu'                                                    => '菜单',
    'Search icon'                                               => '搜索图标',
    'Menu tips'                                                 => '规则任意,不可重复,仅做层级显示,无需匹配控制器和方法',
    'Node tips'                                                 => '控制器/方法名',
    'The non-menu rule must have parent'                        => '非菜单规则节点必须有父级',
    'If not necessary, use the command line to build rule'      => '非必要情况下请直接使用命令行<a href="https://doc.fastadmin.net/docs/command.html#一键生成菜单" target="_blank">php think menu</a>来生成',
    'Name only supports letters, numbers, underscore and slash' => 'URL规则只能是小写字母、数字、下划线和/组成',
];
